# SOL Cleaning Materials — Quotation & Price List Management System

React + TypeScript + Vite management system for SOL Cleaning Materials / SOL Manpower Services Inc.

## GitHub Pages deployment

This project is configured for GitHub Pages through GitHub Actions.

1. Create a **public** GitHub repository.
2. Upload the contents of this project to the repository root.
3. Make sure the default branch is `main`.
4. Open **Settings → Pages** and set **Source** to **GitHub Actions**.
5. Push to `main` (or run the workflow manually under **Actions**).
6. GitHub will build the Vite app and publish the `dist` folder.

The Vite `base` path is set automatically from `BASE_PATH` during the GitHub Actions build, so project-site URLs such as `/sol-cleaning-materials/` work correctly.

## Local development

Prerequisites: Node.js 22+

```bash
npm install
npm run dev
```

Build locally:

```bash
npm run build
```

## Important data/security note

The current application stores its main application database and authentication state in browser `localStorage`. That means data is local to the browser/device and is **not a shared cloud database**.

The project also contains Firebase integration for the Google Drive module. Firebase Authentication, Firestore/Storage rules, and any production API secrets must be configured separately before using this as a multi-user production system.

Do not commit real `.env` or `.env.local` secret files. Only `.env.example` should be committed.
